"""
Date:         12/04/2019
Programmer:   Thelma Nora
Class:        CIST 2472 (Intro to Python)
Description:  This is a note taking program that enables users to save personal notes with a user login protected app.
Saved as:     MyProject/PostIt/admin.py
"""

from django.contrib import admin
from .models import Note, Task

admin.site.register(Note)
admin.site.register(Task)
